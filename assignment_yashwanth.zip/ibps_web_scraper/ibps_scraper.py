import requests
from bs4 import BeautifulSoup
import pandas as pd

URL = "https://www.ibps.in/recruitment-process/recruitment-notifications/"
response = requests.get(URL)
soup = BeautifulSoup(response.text, 'html.parser')

jobs = []

for li in soup.select('li.elementor-icon-list-item'):
    title_tag = li.find('span', class_='elementor-icon-list-text')
    link_tag = li.find('a')

    if title_tag and link_tag:
        job_title = title_tag.text.strip()
        job_link = link_tag['href']
        post_date = ''
        if any(char.isdigit() for char in job_title):
            post_date = ''.join(filter(str.isdigit, job_title))
        jobs.append({
            'Job Title': job_title,
            'Location': 'India',
            'Post/Publish Date': post_date if post_date else 'N/A',
            'Job Link': job_link
        })

df = pd.DataFrame(jobs)
df.to_csv('ibps_jobs.csv', index=False)

print("✅ Scraping completed. Saved as ibps_jobs.csv")
