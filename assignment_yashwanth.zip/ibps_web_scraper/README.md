# IBPS Job Scraper
Author: Yashwanth Royal Ande

## Overview
Scrapes the IBPS official recruitment notifications page and extracts:
- Job Title
- Location
- Publish Date
- Link to job details

## Run Instructions
```bash
pip install -r requirements.txt
python ibps_scraper.py
```
Output: `ibps_jobs.csv`
