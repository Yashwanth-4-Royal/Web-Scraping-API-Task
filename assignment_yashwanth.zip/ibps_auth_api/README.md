# IBPS Auth API
Author: Yashwanth Royal Ande

## Overview
A Django REST API implementing JWT-based login authentication.

### Endpoints
**POST** `/api/login/`
- Accepts username & password
- Returns access & refresh JWT tokens

### Setup
```bash
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser --username=testuser --email=test@example.com
# Password: testpass123
python manage.py runserver
```
Then test:
```bash
POST http://127.0.0.1:8000/api/login/
{
  "username": "testuser",
  "password": "testpass123"
}
```
